package main;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;
import javassist.*;

public class SubstituteMethodBody extends ClassLoader {
	static String _L_ = System.lineSeparator();

	private ClassPool pool;
	static String className;
	static String methodName;
	static String indexName;
	static String value;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] list;
		boolean quit = false;
		ArrayList<String> methodAlreadyModded = new ArrayList<String>();

		do {
			System.out.println(
					"Please enter an application class name, a method name, an index of the method parameter,\n"
							+ "and the value to be assigned to the method parameter--all separated by commas.\n"
							+ "(e.g. ComponentApp, move, 1, 0 or ServiceApp, fill, 2, 10)\n"
							+ "Key \\\"q\\\" to quit.");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
				if (list[i].equals("q")) {
					System.out.println("You have quit the program.");
					sc.close();
					System.exit(0);
				}
			}
			System.out.println("");

			if (list.length != 4) {
				System.out.println("[WRN] Invalid Input size!!\n");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else if (methodAlreadyModded.contains(list[1])) {
				System.out.println("[WRN] This method \'" + list[1] + "\' has been modified!!\n");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else {
				className = "target." + list[0];
				methodName = list[1];
				indexName = list[2];
				value = list[3];

				try {
					SubstituteMethodBody s = new SubstituteMethodBody();
					Class<?> c = s.findClass(className);
					Method mainMethod = c.getDeclaredMethod("main", new Class[] { String[].class });
					mainMethod.invoke(null, new Object[] { args });
				} catch (Exception e) {
					e.printStackTrace();
				}
				methodAlreadyModded.add(list[1]);
			}
			System.out.println("---------------------------------------------------------------");
		} while (!quit);
	}

	public SubstituteMethodBody() throws NotFoundException {
		pool = new ClassPool();
		pool.insertClassPath(new ClassClassPath(new java.lang.Object().getClass()));
	}

	protected Class<?> findClass(String name) throws ClassNotFoundException {
		CtClass cc = null;
		try {
			cc = pool.get(name);
			if (!cc.getName().equals(className)) {
				return defineClass(name, cc.toBytecode(), 0, cc.toBytecode().length);
			}

			cc.instrument(new ExprEditor() {
				public void edit(MethodCall call) throws CannotCompileException {
					String cName = call.getClassName();
					String mName = call.getMethodName();

					if (cName.equals(className) && mName.equals(methodName)) {
						String block1 = "{" + _L_ + "System.out.println(\"\tReset param " + indexName + " to " + value
								+ ".\"); " + _L_ + "$" + indexName + "=" + value + "; " + _L_ + "$proceed($$); " + _L_
								+ "}";
						call.replace(block1);
					}
				}
			});
			byte[] b = cc.toBytecode();
			return defineClass(name, b, 0, b.length);
		} catch (NotFoundException e) {
			throw new ClassNotFoundException();
		} catch (IOException e) {
			throw new ClassNotFoundException();
		} catch (CannotCompileException e) {
			e.printStackTrace();
			throw new ClassNotFoundException();
		}
	}
}
